<!doctype>
<html>
<head>

</head>
<body>
<script>window.alert("please don't tamper with me!")</script>
<?php header("Refresh:0;url='../index.php'"); die();?>
	

</body>
</html>