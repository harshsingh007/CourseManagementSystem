# Think_big_CMS
Course Management system

Course management system build for IIIT Kottayam. It's a compelete project to keep track of record of students and send mails.

A demo website is hosted at 

https://thingbigcms.000webhostapp.com/
